
public interface AlignStrategy {
	
	void printAligned(String text);

}
