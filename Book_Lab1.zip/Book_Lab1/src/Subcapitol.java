/*import java.util.ArrayList;

public class Subcapitol extends Sectiune {
	public ArrayList<Element> elemente;
	public String titlu;
	
	public Subcapitol(String titlu){
		this.titlu = titlu;
		this.elemente = new ArrayList<Element>();
		
	}
	
	public void addElement(Element element){
		this.elemente.add(element);
	}
	
	public void printElemente(){
		System.out.println("Subcapitolul :"+this.titlu);
		for(Element e : this.elemente){
				e.show();
		}
	}
	
}*/
