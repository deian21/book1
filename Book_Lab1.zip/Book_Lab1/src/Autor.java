public class Autor {
	
	private String nume;

	public Autor(){
		this.nume = "";
	}
	public Autor(String nume){
		this.nume = nume;
	}
	
	public String getNume() {
		return nume;
	}
	public void setNume(String nume) {
		this.nume = nume;
	}	
}
