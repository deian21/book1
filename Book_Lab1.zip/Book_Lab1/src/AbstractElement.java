
public abstract class AbstractElement implements ElementPagina {

	
	
	public void addElement(ElementPagina e){
		
	}
	public void removeElement(ElementPagina e){
		
	}
	public int getElements(){
		return 0;
	}
	public void print(){
		
	}
}
