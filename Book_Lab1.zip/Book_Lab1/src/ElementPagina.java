public interface ElementPagina {
	
	
	public void addElement(ElementPagina e);
	public void removeElement(ElementPagina e);
	public int getElements();
	public void print();
	
	
}
