/*import java.util.ArrayList;

public class Capitol {
	private String titlu;
	private ArrayList<Subcapitol> subCapitole;
	
	public Capitol(){
		this.titlu = "";
		this.subCapitole = new ArrayList<Subcapitol>();
	}
	
	public Capitol(String titlu){
		this.titlu = titlu;
		this.subCapitole = new ArrayList<Subcapitol>();
	}
	
	public void addSubcapitol(Subcapitol subcapitol){
		this.subCapitole.add(subcapitol);
	}

	public String getTitlu() {
		return titlu;
	}

	public void setTitlu(String titlu) {
		this.titlu = titlu;
	}

	public ArrayList<Subcapitol> getSubCapitole() {
		return subCapitole;
	}

	public void setSubCapitole(ArrayList<Subcapitol> subCapitole) {
		this.subCapitole = subCapitole;
	}
}*/
