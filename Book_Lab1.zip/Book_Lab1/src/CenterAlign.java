
public class CenterAlign implements AlignStrategy {

	public void printAligned(String text){
		System.out.println("***"+text+"***");
	}

}
