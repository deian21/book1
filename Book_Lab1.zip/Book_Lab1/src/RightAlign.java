
public class RightAlign implements AlignStrategy{
	
	public void printAligned(String text){
		System.out.println(text+"***");
	}
}
